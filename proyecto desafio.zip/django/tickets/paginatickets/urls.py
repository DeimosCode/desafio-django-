from django.urls import path, include
from .views import Ticketlist,Index,CreadorTickets


from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)


app_name= 'paginatickets'

urlpatterns = [
    #serializers
    path('listatickets/', Ticketlist.as_view(),name='lista_tickets'),
    #vistas
    path('', Index.as_view(),name='pagina_index'),
    path('creartickets/', CreadorTickets.as_view(),name='creador_tickets'),
    #jwt simple libreria
    # path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    # path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]