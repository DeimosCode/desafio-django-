from django.apps import AppConfig


class PaginaticketsConfig(AppConfig):
    name = 'paginatickets'
