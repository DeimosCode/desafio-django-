from django.db import models

ESTADOS_TICKETS = (
    ('abi', 'Abierto'),
    ('pen', 'Pendiente'),
    ('enp', 'En Proceso'),
    ('res', 'Resuelto'),
    ('cer', 'Cerrado')
)

# Create your models here.
class Tickets(models.Model):
    titulo = models.CharField(max_length=60,null=True)
    descripcion = models.CharField(max_length=500,null=True)
    estado = models.CharField(max_length=20, choices=ESTADOS_TICKETS)
    fecha = models.DateTimeField(auto_now=True)

    def __str__(self):
        return "Id: %s Titulo: %s   Fecha:  %s"% (self.id, self.titulo,self.fecha.strftime("%Y-%m-%d") )