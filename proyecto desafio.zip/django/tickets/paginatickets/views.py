from django.shortcuts import render
from django.views.generic import detail

from django.views.generic import TemplateView
from django.views.generic.edit import FormView, UpdateView
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView
from django.views.generic.list import ListView
from django.urls import reverse_lazy, reverse
from django.contrib import messages


from django.contrib.auth.decorators import login_required
from rest_framework import status
from rest_framework.response import Response
from rest_framework import generics
from .serializers import TicketsSerializer
from .models import Tickets

from .forms import TicketsForm

class Ticketlist(generics.ListAPIView):

    queryset = Tickets.objects.all()
    serializer_class = TicketsSerializer


    

class Index(TemplateView):
    template_name = 'paginatickets/listatickets.html'



class Index(ListView):
    model = Tickets
    template_name = 'paginatickets/listatickets.html'


    def get_context_data(self,**kwargs):
        context = super().get_context_data(**kwargs)
        context['lista'] = Tickets.objects.all()
        return context

class CreadorTickets(CreateView):
    model = Tickets
    form_class = TicketsForm
    template_name = 'paginatickets/creadortickets.html'

    def get_success_url(self):
        return reverse('paginatickets:pagina_index')