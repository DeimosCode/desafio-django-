from django import forms
from django.forms import ModelForm, widgets
from .models import Tickets

class TicketsForm(forms.ModelForm):
    class Meta:
        model = Tickets
        fields = '__all__'