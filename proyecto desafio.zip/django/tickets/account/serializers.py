from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django.contrib.auth.models import User
from rest_framework import serializers

class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    pass

class CustonUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'