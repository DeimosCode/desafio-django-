
   
from django.shortcuts import render
from django.contrib.auth import authenticate, login

def login_view(request):
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(request, username=username, password=password)
    if user is not None:
        login(request, user)
        return render(request, 'paginatickets/listatickets.html')
    else:
        return render(request, 'account/login.html')
        
from django.contrib.auth import logout

def logout_view(request):
    logout(request)
    return render(request, 'account/login.html')

# from rest_framework_simplejwt.views import TokenObtainPairView
# from account.serializers import CustomTokenObtainPairSerializer,CustonUserSerializer
# from rest_framework.response import Response
# from rest_framework import status,generics
# from django.contrib.auth.models import User
# from rest_framework.views import APIView
# from rest_framework_simplejwt.tokens import  RefreshToken

# class Login(TokenObtainPairView):
#     serializer_class = CustomTokenObtainPairSerializer

#     def post(self,request,*args,**kwargs):
#         username = request.data.get('username','')
#         password = request.data.get('password','')
#         user = authenticate(
#             username = username,
#             password = password
#         )
#         if user:
#             login_serializer = self.serializer_class(data=request.data)
#             if login_serializer.is_valid():
#                 user_serializer = CustonUserSerializer(user)
#                 return Response({
#                     'token':login_serializer.validated_data.get('access'),
#                     'refresh-token':login_serializer.validated_data.get('refresh'),
#                     'user':user_serializer.data,
#                     'message': 'inicio de secion exitosa'
#                 },status=status.HTTP_200_OK)
#             return Response({'error':'Contraseña O nombre de usuario incorrecto'},status=status.HTTP_400_BAD_REQUEST)
#         return Response({'error':'Contraseña O nombre de usuario incorrecto'},status=status.HTTP_400_BAD_REQUEST)

# class Logout(generics.GenericAPIView):

#     def post(self,request,*args,**kwargs):
#         user = User.objects.filter(id=request.data.get('user',''))
#         if user.exists():
#             RefreshToken.for_user(user.first())
#             return Response({'message':'secion serrada correctamente'},status=status.HTTP_205_RESET_CONTENT)
#         return Response({'error':'no existe el usuario'},status=status.HTTP_400_BAD_REQUEST)
