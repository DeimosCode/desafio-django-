import { Component, OnInit, Output } from '@angular/core';

import { Tickets } from './entitys/tickets';
import { TicketsService } from './services/tickets.service';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'frontendtickets';

  handleSearch(value:string){
    this.filtro_values = value
  }
  
  filtro_values = ''


  listaTickets: Tickets[] = [];
  
  constructor(private ticketServices:TicketsService ){
    
  }

  ngOnInit(){
    

    this.ticketServices.getServicios().subscribe((resp:any[]) => this.listaTickets = resp)
   
  }
  
}
