export class Tickets {

    id?:number;
    titulo?:string;
    descripcion?:string;
    estado?:string;
    fecha?:Date;
  
  }
