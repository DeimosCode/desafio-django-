import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Tickets } from '../entitys/tickets';
import { Observable } from 'rxjs';


const header = {headers:new HttpHeaders({'content-type':'application/json'})};

@Injectable({
  providedIn: 'root'
})
export class TicketsService {

  _url = 'http://127.0.0.1:8000/listatickets'

  constructor( private http:HttpClient) { 
    console.log("servicios tickets")
  }

  getServicios():Observable<Tickets[]>{
    return  this.http.get<Tickets[]>(this._url+"/");
  }
}
